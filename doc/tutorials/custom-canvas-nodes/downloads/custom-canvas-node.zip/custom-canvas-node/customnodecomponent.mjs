import { Theme, MenuItem, CnodeComponent } from "@marco.jacovone/cnodes-ui/src/index.mjs";

export class CustomNodeComponent extends CnodeComponent {
  // Factory function
  static instance = (node, canvas) => new CustomNodeComponent(node, canvas);

  constructor(node, canvas) {
    super(node, canvas);
  }

  /**
   * Override this method to add a context menu item "My Custom
   * Action", that simply console logs a message
   */
  getContextMenuItems() {
    let items = super.getContextMenuItems() ?? [];

    items.unshift(
      new MenuItem(
        `<tspan alignment-baseline="middle" style="${Theme.current.MENU_SPECIAL_ITEM_STYLE}">My Custom Action</tspan>`,
        () => {
          console.log("Custom action called");
        }
      )
    );

    return items.length ? items : null;
  }
}
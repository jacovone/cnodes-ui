import {
  InputSocket,
  NextSocket,
  Node,
  OutputSocket,
  PrevSocket,
  Types,
} from "@marco.jacovone/cnodes/cnodes.js";

export class CustomNode extends Node {
  static instance = () => new CustomNode();
  constructor() {
    super("CustomNode", "My Custom Node");

    this.inputs = [new InputSocket("Val", this, Types.STRING, "")];
    this.outputs = [new OutputSocket("Val", this, Types.STRING, "")];
    this.prev = new PrevSocket("In", this);
    this.nexts = [new NextSocket("Out", this)];
  }

  async process() {
      await this.evaluateInputs();
      this.output("Val").value = this.input("Val").value.toString().toUpperCase();
      return this.getFlowResult(this.next("Out"));
  }
}

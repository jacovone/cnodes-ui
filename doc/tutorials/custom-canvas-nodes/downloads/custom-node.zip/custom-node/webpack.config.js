const path = require("path");

module.exports = {
  devtool: "source-map",
  mode: "development",
  entry: ["@babel/polyfill", "./index.js"],
  output: {
    library: "customnode",
    filename: "customnode.bundle.js",
    path: path.resolve(__dirname, "dist"),
  },
  module: {
    rules: [
      {
        test: /\.m?js$/,
        use: {
          loader: "babel-loader",
          options: {
            presets: ["@babel/preset-env"],
            plugins: [
              "@babel/plugin-proposal-class-properties",
              "@babel/plugin-proposal-private-methods",
            ],
          },
        },
      },
    ],
  },
};
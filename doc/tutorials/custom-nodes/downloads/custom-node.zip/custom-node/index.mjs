import { Console, Env, Program } from "@marco.jacovone/cnodes";
import { CustomNode } from "./customnode.mjs";

// Register the node in the cnodes registry
Env.registerNode("My Custom Node", "Custom nodes", CustomNode.instance);

// Create instances
let prg = Program.instance(); // new Program instance
let custom = CustomNode.instance(); // Out custom node instance
let cons = Console.instance(); // a Console node instance
prg.addNode(custom).addNode(cons);

// Define graph and connect sockets
prg.enter.next("Begin").connect(custom.prev);
custom.next("Out").connect(cons.prev);
custom.output("Val").connect(cons.input("Val"));

custom.input("Val").value = "test string";

// Use IEF to launch the async program
(async () => {
  await prg.process();
})();
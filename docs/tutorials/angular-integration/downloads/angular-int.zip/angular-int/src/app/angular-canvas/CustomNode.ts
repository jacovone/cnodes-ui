
export class CustomNode extends cnui.Node {

  static instance = () => new CustomNode();

  constructor() {
    super("a-unique-node-internal-id", "Sample node");
    this.inputs = [
      new cnui.InputSocket("Input1", this, cnui.Types.STRING, "INPUT1"),
      new cnui.InputSocket("Input2", this, cnui.Types.ARRAY, [1, 2, 3]),
      new cnui.InputSocket("Input3", this, cnui.Types.NUMBER, 99)
    ];
    this.outputs = [
      new cnui.OutputSocket("Output", this, cnui.Types.STRING, "OUTPUT"),
    ];
    this.nexts = [
      new cnui.NextSocket("Next", this)
    ]
    this.prev = new cnui.PrevSocket("Previous", this)
  }

  /**
   * Clone this node
   * @param {Function} factory The factory class function
   */
  clone(factory = CustomNode.instance) {
    return super.clone(factory);
  }

  async process() {
    await this.evaluateInputs();
    this.output("Output").value = parseFloat(this.input("Input3").value);

    return this.getFlowResult(this.next("Vai"));
  }
}



export class CustomNodeComponent extends cnui.CnodeComponent {
  // Factory function
  static instance = (node: cnui.Node, canvas: cnui.CnodesCanvas) => new CustomNodeComponent(node, canvas);

  constructor(node: cnui.Node, canvas: cnui.CnodesCanvas) {
    super(node, canvas);
  }

  /**
   * Override this method to add a context menu item "My Custom
   * Action", that simply console logs a message
   */
  getContextMenuItems() {
    let items = super.getContextMenuItems() ?? [];

    items.unshift(
      new cnui.MenuItem(
        `<tspan alignment-baseline="middle" style="${cnui.Theme.current.MENU_SPECIAL_ITEM_STYLE}">My Custom Action</tspan>`,
        () => {
          console.log("Custom action called");
        }
      )
    );

    return items.length ? items : null;
  }
}

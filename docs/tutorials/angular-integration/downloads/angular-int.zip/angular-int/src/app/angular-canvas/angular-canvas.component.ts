import { Component, OnInit } from '@angular/core';
import { CustomNode } from './CustomNode';
import { CustomNodeComponent } from './CustomNodeUI';

@Component({
  selector: 'app-angular-canvas',
  templateUrl: './angular-canvas.component.html',
  styleUrls: ['./angular-canvas.component.css']
})
export class AngularCanvasComponent implements OnInit {

  // Inser this attribute
  private canvas: cnui.CnodesCanvas;

  constructor() { }

  ngOnInit(): void {
    // Insert these lines of code
    setTimeout(() => {
      this.canvas = cnui.canvas("cnodesui");
      let prg = new cnui.Program();

      prg.enter.meta = {
        pos: {
          x: 100,
          y: 100
        }
      }
      prg.exit.meta = {
        pos: {
          x: 700,
          y: 100
        }
      }

      cnui.Env.registerNode("Sample node", "Custom", CustomNode.instance);
      cnui.CnodesCanvas.registerNodeUI(CustomNode.instance(), CustomNodeComponent.instance);
      this.canvas.program = prg;
    });
  }
}

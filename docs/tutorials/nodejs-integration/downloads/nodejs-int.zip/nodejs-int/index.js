// import the cnodes library as "cn"
const cn = require("@marco.jacovone/cnodes");

// Initialize node engine
cn.Env.init();

// Load program definition
let prg = require("./program.json");

// Import the program from definition
let p = cn.Env.import(prg);

// Start the program asynchronously
(async () => {
  await p.process();
})();
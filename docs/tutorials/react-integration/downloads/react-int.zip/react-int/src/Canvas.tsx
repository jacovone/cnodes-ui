/// <reference types="@marco.jacovone/cnodes-ui" />

import React from "react";

export class Canvas extends React.Component {

  private canvas?: cnui.CnodesCanvas;

  public constructor() {
    super({})
  };

  componentDidMount() {
    this.canvas = cnui.canvas("cnodes");
    let prg = new cnui.Program();

    prg.exit.meta = {
      pos: {
        x: 700,
        y: 100
      }
    }

    this.canvas.program = prg;
  }

  render() {
    return (
      <div id="cnodes">
      </div>
    )
  }
}

import { Component, OnInit } from '@angular/core';
import { CustomNode } from './CustomNode';
import { CustomNodeComponent } from './CustomNodeUI';

class MyTheme extends cnui.Theme {
  get CANVAS_BACKGROUND_COLOR(): string {
    return 'lightyellow';
  }
  get CANVAS_SELECTION_STROKE_COLOR(): string {
    return 'blue';
  }
  get CANVAS_SELECTION_FILL_COLOR(): string {
    return 'rgba(0,0,100,0.1)';
  }
  get NODE_FILL_COLOR(): string {
    return 'rgba(23,167,88,0.2)';
  }
}

@Component({
  selector: 'app-angular-canvas',
  templateUrl: './angular-canvas.component.html',
  styleUrls: ['./angular-canvas.component.css'],
})
export class AngularCanvasComponent implements OnInit {
  // Inser this attribute
  private canvas: cnui.CnodesCanvas;

  constructor() {}

  ngOnInit(): void {
    // Insert these lines of code
    cnui.Theme.current = new MyTheme();

    this.canvas = cnui.canvas('cnodesui');
    let prg = new cnui.Program();

    prg.enter.meta = {
      pos: {
        x: 100,
        y: 100,
      },
    };
    prg.exit.meta = {
      pos: {
        x: 700,
        y: 100,
      },
    };

    cnui.Env.registerNode('Sample node', 'Custom', CustomNode.instance);
    cnui.CnodesCanvas.registerNodeUI(
      CustomNode.instance(),
      CustomNodeComponent.instance
    );
    this.canvas.program = prg;
  }
}
